# Permaculture Network Platform

A comprehensive sustainable living platform connecting practitioners, facilitating knowledge sharing, and providing access to resources like seeds, tools, and materials.

**Status:** Production Ready | **Version:** 1.0.0

## 🌍 Overview

The Permaculture Network is a full-stack web application built with:
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Backend:** Supabase (PostgreSQL + Auth)
- **Maps:** Leaflet.js for location-based discovery
- **i18n:** Multi-language support (11 languages)

## 📦 Repository Structure

```
permaculture-network-platform/
├── public/
│   ├── pages/              # HTML pages
│   │   ├── auth.html       # Authentication & onboarding
│   │   ├── dashboard.html  # Main project discovery
│   │   ├── project-detail.html  # Project information with maps
│   │   ├── legal.html      # Privacy, Terms, Cookies
│   │   ├── map-view.html   # Interactive map view
│   │   └── resources.html  # Resource marketplace
│   ├── js/                 # JavaScript modules
│   │   ├── supabase-client.js  # Supabase integration
│   │   └── i18n-translations.js # Language translations
│   └── css/                # Stylesheets (in HTML files)
├── db/
│   └── database-migration.sql  # Database schema
├── docs/                   # Documentation
│   ├── DEPLOYMENT-GUIDE.md
│   ├── PAGES-AND-NAVIGATION.md
│   ├── PROJECT-OVERVIEW.md
│   ├── platform-data-model-guide.md
│   ├── authentication-security-guide.md
│   ├── i18n-implementation-guide.md
│   └── i18n-summary.md
├── config/                 # Configuration files
├── .env.example            # Environment variables template
├── .gitignore              # Git ignore rules
└── README.md               # This file
```

## 🚀 Quick Start

### Prerequisites
- Node.js (optional, for local development)
- Supabase account (free tier available)
- Git

### 1. Clone & Setup

```bash
# Clone the repository
git clone https://github.com/yourusername/permaculture-network-platform.git
cd permaculture-network-platform

# Copy environment template
cp .env.example .env.local
```

### 2. Configure Supabase

1. Create a new project at [supabase.com](https://supabase.com)
2. Go to Project Settings → API
3. Copy your:
   - Project URL
   - Anon Public Key
   - Service Role Key (keep secret!)

### 3. Create Database

1. In Supabase dashboard, go to SQL Editor
2. Create a new query
3. Copy the entire contents of `db/database-migration.sql`
4. Paste into the SQL editor and execute
5. All tables, indexes, and RLS policies are created automatically

### 4. Update Environment Variables

Edit `.env.local`:

```
VITE_SUPABASE_URL=your_project_url
VITE_SUPABASE_ANON_KEY=your_anon_key
VITE_SITE_URL=http://localhost:3000
VITE_ENV=development
```

### 5. Deploy

**Option A: Vercel** (Recommended)
```bash
npm i -g vercel
vercel
```

**Option B: Netlify**
1. Connect GitHub repo
2. Build settings: Leave empty (static site)
3. Deploy

**Option C: GitHub Pages**
1. Enable in repo Settings → Pages
2. Select main branch, /root folder

## 📄 Pages Overview

### Authentication (`public/pages/auth.html`)
- Splash screen
- Login/Register with email
- Magic link authentication
- Password reset
- Profile completion

### Dashboard (`public/pages/dashboard.html`)
- Main project discovery
- Search and filtering
- Card-based project browsing
- Sorting by distance, name, date

### Project Detail (`public/pages/project-detail.html`)
- Full project information
- Interactive map with Leaflet
- Contact information
- Related techniques and plants
- Share and bookmark functionality

### Map View (`public/pages/map-view.html`)
- Interactive map-based discovery
- Real-time filtering by distance
- Sidebar with nearby items
- Directions integration
- Switch between Projects/Resources

### Resources (`public/pages/resources.html`)
- Hierarchical resource categories
  - Seeds
  - Tools
  - Materials
  - Services
  - Information
  - Events
- Advanced filtering by:
  - Category & subcategory
  - Availability
  - Price range
  - Delivery options
  - Distance
- Search functionality

### Legal (`public/pages/legal.html`)
- Privacy Policy (GDPR-compliant)
- Terms of Service
- Cookie Policy

## 🗄️ Database Schema

### Tables
- **users** - User profiles with location
- **projects** - Permaculture & sustainable projects
- **resources** - Marketplace items (seeds, tools, services, etc.)
- **resource_categories** - Hierarchical resource categories
- **project_user_connections** - Project team members
- **favorites** - User bookmarks
- **tags** - Predefined tags and categories

### Security
- Row Level Security (RLS) policies on all tables
- Public profiles are viewable by everyone
- Users can only modify their own data
- Helper functions for location-based queries

### Views
- `v_active_projects` - Projects with creator info
- `v_available_resources` - Resources with provider info

## 🌐 Multi-Language Support

**Supported Languages:**
- ✅ English (Complete)
- ✅ Portuguese (Complete)
- ✅ Spanish (Complete)
- 🔨 French, German, Italian, Dutch, Polish, Japanese, Chinese, Korean (Templates)

**Implementation:**
```javascript
// Switch language
i18n.setLanguage('pt'); // Portuguese
i18n.setLanguage('es'); // Spanish
i18n.setLanguage('en'); // English
```

See `docs/i18n-implementation-guide.md` for details.

## 🔐 Authentication

Supports multiple auth methods:
- Email/Password
- Magic Links (passwordless)
- Session persistence
- Secure token storage

## 📍 Location Features

- Real-time geolocation
- Distance calculations (Haversine formula)
- Nearby discovery (5-500 km radius)
- Map-based visualization
- Directions integration

## 📱 Responsive Design

All pages are mobile-optimized:
- Mobile-first approach
- Touch-friendly controls
- Adaptive layouts (1 col mobile → multi-col desktop)
- Fast loading times

## 🎨 Design System

**Color Palette:**
- Primary Green: `#2d8659`
- Dark Green: `#1a5f3f`
- Light Green: `#f0f7f5`
- Accent Brown: `#d4a574`
- Neutrals: Grays for text and backgrounds

**Typography:**
- Sans-serif: Segoe UI, Tahoma, Geneva (body text)
- Readable and accessible

**Components:**
- Cards with hover effects
- Smooth transitions
- Clear call-to-action buttons
- Organized information hierarchy

## 📊 API Integration

All frontend pages integrate with Supabase via `public/js/supabase-client.js`:

```javascript
// Load projects
const projects = await supabase.getAll('projects', {
  select: '*',
  where: 'status',
  operator: 'eq',
  value: 'active'
});

// Search nearby
const nearby = await supabase.getProjectsByLocation(lat, lon, 50);

// Create resource
await supabase.insert('resources', resourceData);

// Update profile
await supabase.updateUserProfile(userId, profileData);
```

## 🚢 Deployment Checklist

- [ ] Database tables created via SQL migration
- [ ] Supabase authentication configured
- [ ] Environment variables set
- [ ] All pages tested locally
- [ ] Mobile responsiveness verified
- [ ] Links and navigation working
- [ ] Authentication flow complete
- [ ] Custom domain configured (if needed)
- [ ] SSL certificate active
- [ ] Monitoring/Analytics set up
- [ ] Error handling tested

## 📚 Documentation

All documentation is in the `docs/` folder:

- **DEPLOYMENT-GUIDE.md** - Step-by-step deployment instructions
- **PAGES-AND-NAVIGATION.md** - Complete sitemap and navigation flows
- **PROJECT-OVERVIEW.md** - High-level project description
- **platform-data-model-guide.md** - Database schema details
- **authentication-security-guide.md** - Security best practices
- **i18n-implementation-guide.md** - Translation system guide
- **i18n-summary.md** - Quick reference for languages

## 🧪 Testing

### Manual Testing Checklist
- [ ] Sign up creates new user
- [ ] Login with email works
- [ ] Magic link authentication works
- [ ] Password reset works
- [ ] Projects load on dashboard
- [ ] Map displays with markers
- [ ] Search and filters work
- [ ] Navigation between pages works
- [ ] Mobile layout displays correctly
- [ ] Language switching works

### Browser Compatibility
- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security

- HTTPS enforced in production
- XSS protection via HTML escaping
- CSRF protection from Supabase
- Secure session tokens in localStorage
- Row Level Security on all database tables
- No sensitive data in client code

## 📈 Next Phase Features

Planned for Phase 2:
- User profiles with edit capability
- Create/edit projects
- Create/edit resources
- Direct messaging
- Community forums
- Events & workshops
- Admin dashboard
- Advanced analytics

## 🤝 Contributing

We welcome contributions! Please:
1. Fork the repository
2. Create a feature branch
3. Test thoroughly
4. Submit a pull request

## 📞 Support

- **Documentation:** See `docs/` folder
- **Issues:** GitHub Issues
- **Email:** support@example.com

## 📄 License

MIT License - See LICENSE file for details

## 🌱 Mission

To create a global network connecting sustainable living practitioners and facilitating knowledge, resource, and skill sharing to accelerate the transition to regenerative systems.

---

**Version:** 1.0.0  
**Last Updated:** January 2025  
**Status:** Production Ready ✅

