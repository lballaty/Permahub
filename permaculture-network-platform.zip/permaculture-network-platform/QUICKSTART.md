# Quick Start Guide

## 📋 Prerequisites

- Supabase account (free tier: https://supabase.com)
- Git
- Text editor or IDE
- Modern web browser

## 🎯 5-Minute Setup

### Step 1: Create Supabase Project (2 min)

1. Go to https://supabase.com
2. Sign up or log in
3. Create new project
4. Wait for project to initialize

### Step 2: Set Up Database (2 min)

1. In Supabase dashboard, click "SQL Editor"
2. Click "New Query"
3. Copy entire contents of `db/database-migration.sql`
4. Paste into SQL editor
5. Click "Run" button
6. ✅ All tables created!

### Step 3: Get Your Credentials (1 min)

1. In Supabase, go to **Settings → API**
2. Copy **Project URL** (https://xxxx.supabase.co)
3. Copy **anon public key** (starts with eyJ...)
4. Paste into `.env.local`:

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```

### Step 4: Deploy (Choose One)

**Option A: Vercel (Easiest)**
```bash
npm i -g vercel
vercel
# Follow prompts, connect your GitHub
```

**Option B: GitHub Pages**
```bash
git init
git add .
git commit -m "Initial commit"
git push origin main
# Then enable Pages in Settings
```

**Option C: Netlify**
```bash
npm i -g netlify-cli
netlify deploy
```

## ✅ Testing After Deploy

1. Visit your deployed URL
2. Create test account at `/auth`
3. Check `/dashboard` loads projects
4. Try `/map-view` (if you have location permission)
5. Browse `/resources`

## 🐛 Troubleshooting

**"Supabase connection error"**
- Check SUPABASE_URL is correct in .env.local
- Check anon key is correct
- Ensure project is active in Supabase dashboard

**"Projects not loading"**
- Verify database migration ran successfully
- Check browser console for errors (F12)
- Ensure you have projects in database

**"Auth not working"**
- Check email auth is enabled in Supabase
- Verify redirect URLs in Supabase Auth settings
- Check browser allows localStorage

## 📖 Full Documentation

For detailed information, see:
- `docs/DEPLOYMENT-GUIDE.md` - Complete deployment guide
- `docs/platform-data-model-guide.md` - Database schema
- `docs/PAGES-AND-NAVIGATION.md` - All pages explained
- `README.md` - Project overview

## 🚀 Next Steps

After initial setup:

1. **Add test data** - Create sample projects in database
2. **Customize branding** - Update colors/text in pages
3. **Set up custom domain** - Point domain to your hosting
4. **Enable analytics** - Add Google Analytics tracking
5. **Plan Phase 2** - User profiles, create projects, etc.

## 💬 Getting Help

- Check `docs/` folder for detailed guides
- Review browser console for errors (F12)
- Check Supabase documentation: https://supabase.com/docs
- Common issues guide: `docs/DEPLOYMENT-GUIDE.md` → Troubleshooting

---

**Questions?** Check the detailed documentation files!

